public class InvalidWardException extends Exception{
    public InvalidWardException(String str){
        super(str);
    }
}
