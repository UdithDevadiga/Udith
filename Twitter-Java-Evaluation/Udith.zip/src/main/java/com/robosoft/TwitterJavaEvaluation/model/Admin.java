package com.robosoft.TwitterJavaEvaluation.model;

import lombok.Data;

@Data
public class Admin {
    private String adminId;
    private String password;
}
