package com.robosoft.TwitterJavaEvaluation.model;

import lombok.Data;

@Data
public class Followers {
    private String userId;
    private String followerId;
}
