package com.robosoft.TwitterJavaEvaluation.model;

import lombok.Data;

@Data
public class CommentLikes {
    private String userId;
    private String commentId;
}
