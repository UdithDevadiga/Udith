package com.robosoft.TwitterJavaEvaluation.model;

import lombok.Data;
@Data
public class SignIn {
    private String userId;
    private String password;
}
