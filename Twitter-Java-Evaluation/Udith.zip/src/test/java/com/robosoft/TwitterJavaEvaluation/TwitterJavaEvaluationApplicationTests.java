package com.robosoft.TwitterJavaEvaluation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitterJavaEvaluationApplicationTests {

	@Test
	void contextLoads() {
	}

}
